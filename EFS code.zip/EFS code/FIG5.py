# coding=UTF-8
import copy
import numpy as np
import pandas as pd
from numpy.random import seed
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import MinMaxScaler
#import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def read77():
    data = pd.read_csv("final2.csv", header=None)
    # select_feature = [1, 2, 3, 4]
    select_feature = [1,6,10,14]
    # select_feature = range(19)
    return copy.deepcopy(data.values), data.values[:, select_feature], data.values[:, 16]

def Center_r(X):

    scaler = MinMaxScaler()
    scaler.fit(X)
    X_nor = scaler.transform(X)
    #writedata("guiyi.xlsx", X_nor)
    m,n=X_nor.shape
    X_center=np.zeros((1,4))
    # X_min=scaler.transform([[7.2442, 0.475, 285.32, 3.12]])
    # X_max= scaler.transform([[11.9107,0.589, 415.09, 5.294]])
    # X_min=scaler.transform([[7.24, 0.40, 283.1, 2.92]])
    # X_max= scaler.transform([[11.91,0.55, 414.09, 5.094]])
    # X_min = scaler.transform([[230, 5.938, 6.610,  3]])
    #     X_max = scaler.transform([[500, 10.5425, 6.816,  10]])
    X_min = scaler.transform([[230, 5.938, 6.6103,  3]])
    X_max = scaler.transform([[500, 10.5425, 6.816,  10]])
    #X_min = scaler.transform([[220, 5.518, 6.613,3]])   1111111111
    #X_max = scaler.transform([[460, 12.9425, 6.770,10]])
    # X_min = scaler.transform([[220, 5.318, 6.613, 3]])  22222222
    # X_max = scaler.transform([[460, 12.9425, 6.770, 10]])
    for i in range(4):
        X_center[0,i]=X_min[0,i]+(X_max[0,i]-X_min[0,i])/2.0
    r=np.max(X_max-X_min)/2.0
    # print(X_max-X_min)
    # print ("X_center=",X_center)
    # print ("r=",r)
    return X_center,r

import xlsxwriter

def dataDivide77(X,y,Center,r):

    scaler = MinMaxScaler()
    scaler.fit(X)
    X_nor = scaler.transform(X)
    #picture(X_nor, y)
    AA = np.zeros((2, 4))
    AA[0] = [426.5197, 21.2614, 6.6897, 8]
    AA[1] = [299.0513, 11.1159, 6.6807, 8]
    AA1 = scaler.transform(AA)
    m, n = X_nor.shape
    liner=[]
    nonlinear=[]
    y_liner=[]
    y_nonlinear=[]
    d1 = np.linalg.norm(AA1[0, :] - Center)
    d2 = np.linalg.norm(AA1[1, :] - Center)
    # print("AA1=",AA1)
    # print("d1=",d1)
    # print("d2=",d2)
    # if d1 > r:
    #     print("STA-28 linear data ===")
    # else:
    #     print("STA-28 nonlinear data ===")
    # if d2 > r:
    #     print("PST-5 linear data ===")
    # else:
    #     print("PST-5 nonlinear data ===")
    for i in range(m):
        d=np.linalg.norm(X_nor[i,:]-Center)

        if d>r:
            liner.append(X[i,:])
            y_liner.append(y[i])
        else:
            nonlinear.append(X[i,:])
            y_nonlinear.append(y[i])
    llinear=np.array(liner)
    yylinear=np.array(y_liner)
    lnonlinear = np.array(nonlinear)
    yynonlinear = np.array(y_nonlinear)
    return llinear,yylinear,lnonlinear,yynonlinear

def dataDivide80000(XX,Center,r):
    scaler = MinMaxScaler()
    X=XX[:,1:]
    scaler.fit(X)
    X_nor = scaler.transform(X)
    # AA=np.zeros((1,5))
    # AA[0] = [15.4081,426.5197,3.513,6.6897,8]
    # AA1=scaler.transform(AA)
    #picture(X_nor, y)
    m, n = X_nor.shape
    liner=[]
    nonlinear=[]
    # d1 = np.linalg.norm(AA1[0, :] - Center)
    # if d1 > r:
    #     print("linear data ===")
    # else:
    #     print("nonlinear data ===")
    for i in range(m):
        d=np.linalg.norm(X_nor[i,:]-Center)

        if d>r:
            liner.append(XX[i,:])
        else:
            nonlinear.append(XX[i,:])
    llinear=np.array(liner)

    lnonlinear = np.array(nonlinear)

    return llinear,lnonlinear

def figs(datalabel1,datalabel2,labels1,lables2,name,m):
    fig = plt.figure()
    ax = Axes3D(fig)
    ax.scatter(datalabel1[:, m], datalabel1[:, 1],labels1[0,:], marker='o', c='', edgecolors='blue', s=20,
                label='Pure AIPOs')

    ax.scatter(datalabel2[:, m], datalabel2[:, 1], lables2[0,:],marker='o', c='', edgecolors='r', s=20,
                label='Heteroatom-stabilized AIPOs')
    #plt.scatter(datalabel3[:, m], datalabel3[:, 1], marker='o', c='', edgecolors='orange', s=20,            label='Hybrid AIPOs')
    # plt.scatter(data2[:, 2], data2[:, 1], marker='+', color='green', s=20, label='the same Heteroatom-stabilized AIPO 10618')
    ax.set_zlabel('label', fontdict={'size': 15})
    ax.set_ylabel(u"ΔE", fontdict={'size': 15})
    ax.set_xlabel(name, fontdict={'size': 15})
    ax.legend(loc='best')
    plt.show()

def picture(datalabel1,datalabel2,name,m):

    num_row1, num_clumn1 = datalabel1.shape
    num_row2, num_clumn2 = datalabel2.shape
    labels1=np.ones((num_row1,1))
    labels2=np.ones((num_row2,1))*2
    x1 = datalabel1[:, m]
    y1 = datalabel1[:, 1]
    z1 = labels1[:,0]

    x2 = datalabel2[:, m],
    y2 = datalabel2[:, 1],
    z2 = labels2[:,0]



    # 绘制散点图
    fig = plt.figure()
    ax = Axes3D(fig)
    ax.scatter(x1, y1, z1, c='r', label='Pure AIPOs')
    ax.scatter(x2, y2, z2, c='g',label='Heteroatom-stabilized AIPOs')

    # 绘制图例
    ax.legend(loc='best')

    # 添加坐标轴(顺序是Z, Y, X)
    ax.set_zlabel('label', fontdict={'size': 12, 'color': 'black'})
    ax.set_ylabel("P-Al-P", fontdict={'size': 12, 'color': 'black'})
    ax.set_xlabel(name, fontdict={'size': 12, 'color': 'black'})
    ax.view_init(elev=90, azim=45)
    # 展示
    plt.show()

def picture77(datalabel1,datalabel2,name,m):

    num_row1, num_clumn1 = datalabel1.shape
    num_row2, num_clumn2 = datalabel2.shape
    labels1=np.ones((num_row1,1))
    labels2=np.ones((num_row2,1))*2
    x1 = datalabel1[:, m]
    y1 = datalabel1[:, 0]
    z1 = labels1[:,0]

    x2 = datalabel2[:, m],
    y2 = datalabel2[:, 0],
    z2 = labels2[:,0]



    # 绘制散点图
    fig = plt.figure()
    ax = Axes3D(fig)
    ax.scatter(x1, y1, z1, c='r', label='Pure AIPOs')
    ax.scatter(x2, y2, z2, c='g', label='Heteroatom-stabilized AIPOs')
    plt.tick_params(labelsize=9)
    # 绘制图例
    ax.legend(loc='best')

    # 添加坐标轴(顺序是Z, Y, X)
    ax.set_zlabel('label', fontdict={'size': 9, 'color': 'black'})
    ax.set_ylabel("P–Al–P angle variance", fontdict={'size': 9, 'color': 'black'})
    ax.set_xlabel(name, fontdict={'size': 9, 'color': 'black'})
    ax.view_init()
    # 展示
    plt.show()
#datalabel1,datalabel2,labels1,lables2,name,m
# def picture(Test, y):
#     num_row, num_clumn = Test.shape
#     row1 = []
#     row2 = []
#     for i in range(num_row):
#         if y[i] == 1:
#             row1.append(i)
#         else:
#             row2.append(i)
#     number1 = np.delete(Test, row2, axis=0)
#     number2 = np.delete(Test, row1, axis=0)
#
#     important_feature = [0, 1, 2]
#     data1 = number1[:, important_feature]
#     x1 = datalabel1[:, 0]
#     y1 = data1[:, 1]
#     z1 = data1[:, 2]
#
#     data2 = number2[:, important_feature]
#     x2 = data2[:, 0]
#     y2 = data2[:, 1]
#     z2 = data2[:, 2]
#
#
#
#     # 绘制散点图
#     fig = plt.figure()
#     ax = Axes3D(fig)
#     ax.scatter(x1, y1, z1, c='r', label='red')
#     ax.scatter(x2, y2, z2, c='g', label='green')
#
#     # 绘制图例
#     ax.legend(loc='best')
#
#     # 添加坐标轴(顺序是Z, Y, X)
#     ax.set_zlabel('Z', fontdict={'size': 15, 'color': 'red'})
#     ax.set_ylabel('Y', fontdict={'size': 15, 'color': 'red'})
#     ax.set_xlabel('X', fontdict={'size': 15, 'color': 'red'})
#
#     # 展示
#     plt.show()

def read80000():
    data = pd.read_csv("Hypo80000name.csv", header=None)
    select_feature = [0,12,17,19,20]
    # select_feature = range(19)
    return data.values[:, select_feature]


def tongji(predict_XXlabel,XX_name):
    #data12 = pd.read_csv("Label1_2.csv", header=None)
    #All_data12 = data12.values

    n= XX_name.shape[0]

    data1 = []
    data2 = []
    data3 = []
    data4 = []
    NN1=0
    NN2=0
    for i in range(n):
        #if XX_name[i] in All_data12[:, 0]:
            if predict_XXlabel[i] == 1:
                NN1+=1
        #     else:
        #         data3.append(XX_name[i])
        # if XX_name[i] in All_data12[:, 1]:
            if predict_XXlabel[i] == 2:
                NN2+=1  # 与标签2 一致的
            # else:
            #     data4.append(XX_name[i])

    N1=len(data1)
    N2=len(data2)
    N3=len(data3)
    N4=len(data4)

    # data1 = np.array(data1)
    # data2 = np.array(data2)
    # data3 = np.array(data3)
    # data4 = np.array(data4)
    # N1, M1 = data1.shape
    # N2, M2 = data2.shape
   # N3, M3 = data3.shape
   # N4, M4 = data4.shape
    print("number of  label 1 =", NN1)
    print("number of  label 2 =", NN2)
    return NN1,NN2

def writedata(filname, data):
    """
      功能：存储调用MDDM_proj和MDDM_spc两个函数的结果
      参数：
    """
    m, n = np.shape(data)
    workbook = xlsxwriter.Workbook(filname)
    worksheet = workbook.add_worksheet()
    for i in range(m):
        for j in range(n):
            worksheet.write(i, j, data[i, j])
    workbook.close()

def tongjiwrite(predict_XXlabel,XX_data):
    # data12 = pd.read_csv("Label1_2.csv", header=None)
    # All_data12 = data12.values

    n= XX_data.shape[0]

    data1PP = []
    data2PP = []
    data3PP=[]

    data1PALP = []
    data2PALP = []
    data3PALP = []

    data1CShM = []
    data2CShM = []
    data3CShM = []
    labelss1=[]
    labelss2=[]
    for i in range(n):
        if predict_XXlabel[i] == 1:

                data1PP.append(XX_data[i])
                labelss1.append(1)

        if predict_XXlabel[i] == 2:

                data2PP.append(XX_data[i])
                labelss2.append(2)

    data11PP = np.array(data1PP)
    data22PP = np.array(data2PP)
    #data33PP = np.array(data3PP)
    labels1=np.array(labelss1)
    labels2=np.array(labelss2)
    # data11PALP = np.array(data1PALP)
    # data22PALP = np.array(data2PALP)
    # data33PALP = np.array(data3PALP)
    #
    # data11CShM = np.array(data1CShM)
    # data22CShM = np.array(data2CShM)
    # data33CShM = np.array(data3CShM)

    #figs(data11PP,data22PP,labels1,labels2,"P-P",2)
    #跑8万个的图
    # picture(data11PP,data22PP,"O-Al-O",2)
    # picture(data11PP, data22PP, "AlO4 Volume", 3)
    # picture(data11PP, data22PP, "Num.Operators", 4)
    #77个数据集的图
    picture77(data11PP, data22PP, "O–Al–O angle variance", 1)
    picture77(data11PP, data22PP, "$AlO_4$ Volume", 2)
    picture77(data11PP, data22PP, "Num. Operators", 3)
    # figs(data11PALP, data22PALP,data33PALP, "P-Al-P", 3)
    # figs(data11CShM, data22CShM,data33CShM, "CShM", 4)



import matplotlib.pyplot as plt




if __name__ == "__main__":
    X_y, X, y = read77()
    X_all=read80000()
    Center,r=Center_r(X)  #计算球的中心Center和半径r
    AA=np.zeros((2,4))
    AA[0]=[426.5197,21.2614,6.6897,8]
    AA[1] = [299.0513, 11.1159, 6.6807, 8]
    X_liner,ylinear,x_nonlinear,ynonlinear=dataDivide77(X,y,Center,r)
    XX_liner, XX_nonlinear= dataDivide80000(X_all, Center, r)
    XX_linearname=XX_liner[:,0]
    XX_nonlinearname = XX_nonlinear[:, 0]
    XX_lineardata=XX_liner[:,1:]
    XX_nonlineardata = XX_nonlinear[:, 1:]
    linearnumb,n1=X_liner.shape
    nonlinearnumb,n2= x_nonlinear.shape
    # print("77 linear=",X_liner.shape)
    # print("77 nonlinear=", x_nonlinear.shape)
    # print("80000 linear=", XX_liner.shape)
    # print("80000 nonlinear=", XX_nonlinear.shape)
    score=[]
    prs=[]
    C1=[1000]
    C2 = [100]
    for cc1 in C1:
        for cc2 in C2:
    # cc1 = 1000.0
    # cc2 = 10.0
    #print("cc1=", cc1)
            clf = SVC(kernel='linear', C=cc1, gamma="auto")
            M = clf.fit(X_liner, ylinear)
            predict_labell = clf.predict(X_liner)
            predict_XXlinear = clf.predict(XX_lineardata)
            predictX = clf.predict(AA)
            #print("the result STA-28 and PST-5=",predictX)

            # ==============nonlinear=============
            nonclf = SVC(kernel='rbf', C=cc2, gamma="auto")
            nonclf.fit(x_nonlinear, ynonlinear)
            predict_labelnon = nonclf.predict(x_nonlinear)
            predictX = nonclf.predict(AA)
            print("the result STA-28 and PST-5=", predictX)
            predict_XXnonlinear = nonclf.predict(XX_nonlineardata)

            # =============合并==================
            predict_label = np.hstack((predict_labell, predict_labelnon))  # 合并线性和非线性的结果
            yy = np.hstack((ylinear, ynonlinear))
            XX_data77 = np.vstack((X_liner, x_nonlinear))

            # print("yy true=",yy)
            # print("pr true=",predict_label)
            score_1 = precision_score(yy, predict_label)
            score_2 = precision_score(yy, predict_label, pos_label=2)
            print("score_1=",score_1)
            print("score_2=",score_2)
            score.append((score_1, score_2))

            predict_XXlabel = np.hstack((predict_XXlinear, predict_XXnonlinear))  # 合并线性和非线性的结果
            XX_name = np.hstack((XX_linearname, XX_nonlinearname))
            aa1, aa2 = XX_liner.shape
            bb1, bb2 = XX_nonlinear.shape
            XX_data = np.vstack((XX_liner, XX_nonlinear))
            NN1, NN2 = tongji(predict_XXlabel, XX_name)
            prs.append((cc1, cc2, score_1, score_2, NN1, NN2))
            tongjiwrite(predict_label, XX_data77)
            #tongjiwrite(predict_XXlabel,  XX_data)
    # errorlabel1 = []
    # errorlabel2 = []
    # datalabel1 = []
    # datalabel2 = []
    # for i in range(77):
    #     if yy[i] == 1 and yy[i] == predict_label[i]:
    #         if i <= linearnumb - 1:
    #             datalabel1.append(X_liner[i])
    #         else:
    #             datalabel1.append(x_nonlinear[i - linearnumb])
    #     elif yy[i] == 2 and yy[i] == predict_label[i]:
    #         if i <= linearnumb - 1:
    #             datalabel2.append(X_liner[i])
    #         else:
    #             datalabel2.append(x_nonlinear[i - linearnumb])
    #
    # for i in range(77):
    #     if yy[i] != predict_label[i] and i <= linearnumb - 1:
    #         if yy[i] == 1:
    #             errorlabel1.append(X_liner[i])
    #         else:
    #             errorlabel2.append(X_liner[i])
    #
    #     elif yy[i] != predict_label[i] and i > linearnumb - 1:
    #         if yy[i] == 1:
    #             errorlabel1.append(x_nonlinear[i - linearnumb])
    #         else:
    #             errorlabel2.append(x_nonlinear[i - linearnumb])
    #         # print("nonlinear label=", yy[i])
    # data1 = np.array(datalabel1)
    # data2 = np.array(datalabel2)
    # data3 = np.array(errorlabel1)
    # data4 = np.array(errorlabel2)


    aa = 0










