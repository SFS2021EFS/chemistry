# coding=UTF-8
import copy
import numpy as np
import pandas as pd
from numpy.random import seed
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import MinMaxScaler
#import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import skfeature.utility.entropy_estimators as ees
import skfeature.function.information_theoretical_based.MIM as mim
import skfeature.function.information_theoretical_based.MRMR as mrmr


def read77():
    data = pd.read_csv("known77.csv", header=None)
    # select_feature = [1, 2, 3, 4]
    #select_feature = [0,10,11,12]
    # select_feature = range(19)
    return  data.values[:, :19], data.values[:, 19]

def Center_r(X):

    scaler = MinMaxScaler()
    scaler.fit(X)
    X_nor = scaler.transform(X)
    #writedata("guiyi.xlsx", X_nor)
    m,n=X_nor.shape
    X_center=np.zeros((1,4))
    # X_min=scaler.transform([[7.2442, 0.475, 285.32, 3.12]])
    # X_max= scaler.transform([[11.9107,0.589, 415.09, 5.294]])
    # X_min=scaler.transform([[7.24, 0.40, 283.1, 2.92]])
    # X_max= scaler.transform([[11.91,0.55, 414.09, 5.094]])
    X_min = scaler.transform([[7.0, 0.415, 285.1, 3.02]])
    X_max = scaler.transform([[11.9107, 0.589, 415.09, 5.294]])

    for i in range(4):
        X_center[0,i]=X_min[0,i]+(X_max[0,i]-X_min[0,i])/2.0

    r=np.max(X_max-X_min)/2.0
    print ("X_center=",X_center)
    print ("r=",r)
    return X_center,r

import xlsxwriter

def dataDivide77(X,y,Center,r):

    scaler = MinMaxScaler()
    scaler.fit(X)
    X_nor = scaler.transform(X)
    #picture(X_nor, y)
    m, n = X_nor.shape
    liner=[]
    nonlinear=[]
    y_liner=[]
    y_nonlinear=[]
    for i in range(m):
        d=np.linalg.norm(X_nor[i,:]-Center)
        if d>r:
            liner.append(X[i,:])
            y_liner.append(y[i])
        else:
            nonlinear.append(X[i,:])
            y_nonlinear.append(y[i])
    llinear=np.array(liner)
    yylinear=np.array(y_liner)
    lnonlinear = np.array(nonlinear)
    yynonlinear = np.array(y_nonlinear)
    return llinear,yylinear,lnonlinear,yynonlinear

def dataDivide80000(XX,Center,r):
    scaler = MinMaxScaler()
    X=XX[:,1:]
    scaler.fit(X)
    X_nor = scaler.transform(X)
    #picture(X_nor, y)
    m, n = X_nor.shape
    liner=[]
    nonlinear=[]
    for i in range(m):
        d=np.linalg.norm(X_nor[i,:]-Center)
        if d>r:
            liner.append(XX[i,:])
        else:
            nonlinear.append(XX[i,:])
    llinear=np.array(liner)

    lnonlinear = np.array(nonlinear)

    return llinear,lnonlinear




def read80000():
    data = pd.read_csv("Hypo80000name.csv", header=None)
    select_feature = [0,1,11,12,13]
    # select_feature = range(19)
    return data.values[:, select_feature]


def tongji(predict_XXlabel,XX_name):
    data12 = pd.read_csv("Label1_2.csv", header=None)
    All_data12 = data12.values

    n= XX_name.shape[0]

    data1 = []
    data2 = []
    data3 = []
    data4 = []

    for i in range(n):
        if XX_name[i] in All_data12[:, 0]:
            if predict_XXlabel[i] == 1:
                data1.append(XX_name[i])  # 与标签1 一致的
            else:
                data3.append(XX_name[i])
        if XX_name[i] in All_data12[:, 1]:
            if predict_XXlabel[i] == 2:
                data2.append(XX_name[i])  # 与标签2 一致的
            else:
                data4.append(XX_name[i])

    N1=len(data1)
    N2=len(data2)
    N3=len(data3)
    N4=len(data4)

    # data1 = np.array(data1)
    # data2 = np.array(data2)
    # data3 = np.array(data3)
    # data4 = np.array(data4)
    # N1, M1 = data1.shape
    # N2, M2 = data2.shape
   # N3, M3 = data3.shape
   # N4, M4 = data4.shape
    print("number of consistent label 1 =", N1)
    print("number of consistent label 2 =", N2)

def writedata(filname, data):
    """
      功能：存储调用MDDM_proj和MDDM_spc两个函数的结果
      参数：
    """
    m, n = np.shape(data)
    workbook = xlsxwriter.Workbook(filname)
    worksheet = workbook.add_worksheet()
    for i in range(m):
        for j in range(n):
            worksheet.write(i, j, data[i, j])
    workbook.close()





import matplotlib.pyplot as plt

def discrete_5(X):
    """
    功能：数据集离散方法 分箱法(箱数=5)
    """
    sample_row,sample_colum=np.shape(X)
    for i in range(sample_colum):
        m=pd.cut(X[:,i],5,labels=[0,1,2,3,4])
        for j in range(sample_row):
            X[j,i]=m[j]
    return X

def discrete_3(X):
    """
    功能：数据集离散方法 分箱法(箱数=5)
    """
    sample_row,sample_colum=np.shape(X)
    for i in range(sample_colum):
        m=pd.cut(X[:,i],3,labels=[0,1,2])
        for j in range(sample_row):
            X[j,i]=m[j]
    return X

def discrete_10(X):
    """
    功能：数据集离散方法 分箱法(箱数=5)
    """
    sample_row,sample_colum=np.shape(X)
    for i in range(sample_colum):
        m=pd.cut(X[:,i],10,labels=[0,1,2,3,4,5,6,7,8,9])
        for j in range(sample_row):
            X[j,i]=m[j]
    return X


def CRxy(fi, fj, C):
    IC = ees.cmidd(fi, C, fj)
    I = ees.midd(fi, C)
    HF = ees.entropyd(fi)
    HC = ees.entropyd(C)
    rr = (IC-I)/(HF+HC)
    CR = 2*rr
    #print CR
    return CR

def DRJMIM(X,y,k):
    GS=[]  #存取选择的特征标签
    DR=[]
    Is=[]
    DRR=[]  #存取最终的最大值结果
    n_samples, n_features = X.shape
    for i in range(n_features): #所有特征与类的互信息
        f = X[:, i]
        Is.append(ees.midd(f, y))
    DR=Is     #初始化DR
    DRR=Is
    flag=0
    while len(GS)<k:
        index=DRR.index(max(DRR))
        GS.append(index)
        DRR[index]=-1000  #将已选特征赋成一个小数
        if max(DRR)<0:
            print ("负数特征索引:",index)
            flag=1
        for i in range(n_features):
            if i not in GS:
                fi=X[:, i]
                f=X[:, index]
                CRG=CRxy(fi,f,y)
                DR[i]=DR[i]+CRG*ees.midd(f,y)
                CI=np.ones(len(GS))  #初始化存储联合互信息
                CI=CI*1000
                mm=0
                for j in GS:
                    f=X[:, j]
                    CI[mm]=ees.midd(y,f)+ees.cmidd(y,fi,f)
                    mm=mm+1
                DRR[i]=min(CI)*DR[i]
    if flag==0:
        print ("无负数特征索引.")
    return GS


def DCSF(X,y,k):
    t1=[]
    n_samples, n_features = X.shape
    for i in range(n_features):   #所有特征与类的互信息
        f = X[:, i]
        t1.append(ees.midd(f, y))
    F=[]
    maxs =np.zeros(n_features)
    while len(F)<k:
        if len(F)==0:
            index=t1.index(max(t1))
            F.append(index)
            f_select = X[:, index]
        j_mim = -1000000000000
        for i in range(n_features):
            if i not in F:
                fi=X[:, i]
                maxs[i]=maxs[i]+ees.cmidd(y, f_select,fi)+ees.cmidd(y, fi,f_select)-ees.midd(f_select,fi)
                t=maxs[i]
                if t>j_mim:
                    j_mim = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F

def WRFS(X,y,k):
    """
    功能：新算法
    """
    t1=[]
    n_samples, n_features = X.shape
    for i in range(n_features):   #所有特征与类的互信息
        f = X[:, i]
        t1.append(ees.midd(f, y))
    F=[]
    maxs =np.zeros(n_features)
    Hy=ees.entropyd(y)
    while len(F)<k:
        if len(F)==0:
            index=t1.index(max(t1))
            F.append(index)
            f_select = X[:, index]
        j_mim = -1000000000000
        for i in range(n_features):
            if i not in F:
                fi=X[:, i]
                mi_selected=ees.midd(f_select,y)
                cmi_fi=ees.cmidd(y, f_select,fi)
                cmi_select=ees.cmidd(y,fi ,f_select)
                jointI=cmi_fi + t1[i]
                w1=jointI/float(Hy)
                w2=mi_selected/float(Hy)
                r=ees.midd(fi,f_select)
                #if r< 1e-12:
                  #  r=0
                mm=w1*cmi_select+w2*cmi_fi-r
                maxs[i]=maxs[i]+mm
                t=maxs[i]
                if t>j_mim:
                    j_mim = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F

def N_MRMCR_MI(X,y,k):
    """
    功能：新算法
    """
    t1=[]
    n_samples, n_features = X.shape
    Iy=ees.midd(y,y)
    for i in range(n_features):   #所有特征与类的互信息
        f = X[:, i]
        ff=ees.midd(f, y)/float(Iy)
        t1.append(ff)
    F=[]
    maxs =np.ones(n_features)*(-100000000)

    while len(F)<k:
        if len(F)==0:
            index=t1.index(max(t1))
            F.append(index)
            f_select = X[:, index]
        j_mim = -1000000000000
        for i in range(n_features):
            if i not in F:
                fi=X[:, i]
                Ifi=ees.midd(fi,y)
                Iselected=ees.midd(f_select,y)
                minn=min(Ifi,Iselected)
                Ifi_selected=ees.midd(f_select,fi)
                maxn=max(Ifi,Iselected,Ifi_selected)
                if maxn*Iy==0:
                    nn=1
                    print ("######")
                else:
                    nn=maxn*Iy
                temp=(Ifi_selected*minn)/nn
                if maxs[i]<temp:
                    maxs[i]=temp
                t=t1[i]-maxs[i]
                if t>j_mim:
                    j_mim = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F

def MR_MNCI(X,y,k):
    t1=[]
    n_samples, n_features = X.shape
    for i in range(n_features):   #所有特征与类的互信息
        f = X[:, i]
        t1.append(ees.midd(f, y))
    F=[]
    R =np.zeros(n_features)
    mins=1000000*np.ones(n_features)
    while len(F)<k:
        if len(F)==0:
            index=t1.index(max(t1))
            F.append(index)
            f_select = X[:, index]
        j_mim = -1000000000000
        n_s=len(F)
        for i in range(n_features):
            if i not in F:
                fi=X[:, i]
                R[i]=R[i]+ees.midd(f_select,fi)
                rr=R[i]*(1/float(n_s))
                conI=ees.cmidd(fi,y,f_select)
                if conI<mins[i]:
                    mins[i]=conI
                t=t1[i]+mins[i]-rr
                if t>j_mim:
                    j_mim = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F

def cfr(X,y,k):
    """
    功能：新算法
    """
    t1=[]
    n_samples, n_features = X.shape
    for i in range(n_features):   #所有特征与类的互信息
        f = X[:, i]
        t1.append(ees.midd(f, y))
    F=[]
    tt =np.zeros(n_features)

    while len(F)<k:
        if len(F)==0:
            index=t1.index(max(t1))
            F.append(index)
            f_select = X[:, index]
        j_mim = -1000000000000
        for i in range(n_features):
            if i not in F:
                fi=X[:, i]
                cmi=ees.cmidd(y,fi ,f_select)
                inter =t1[i]-cmi
                tt[i] +=cmi-inter
                t=tt[i]
                if t> j_mim:
                    j_mim = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F

def MRMD(X,y,n_selected_features):
    """
    功能：新算法
    """
    n_samples, n_features = X.shape
    F = []
    t1 = np.zeros(n_features)
    t2 = np.zeros(n_features)
    for i in range(n_features):
        f = X[:, i]
        t1[i] = ees.midd(f, y)
    while True:
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            f_select = X[:, idx]
        if len(F) == n_selected_features:
            break
        j_cmi = -1000000000000

        beta = 1.0 / len(F)
        for i in range(n_features):
            if i not in F:
                f = X[:, i]
                t2[i] += ees.midd(f_select, f)-ees.cmidd(f,y,f_select)
                t = t1[i] - beta*t2[i]
                if t > j_cmi:
                    j_cmi = t
                    idx = i
        F.append(idx)
        f_select = X[:, idx]
    return F


if __name__ == "__main__":

    data = pd.read_csv("final2.csv", header=None)
    X=data.values[:, :16]
    y=data.values[:, 16]
    XX=discrete_5(X)
    F, v1, v2=mim.mim(XX,y,n_selected_features=16)
    F=np.array(F)
    F=F+1
    print("MIM=",F)

    F = DCSF(XX, y, k=16)
    F = np.array(F)
    F = F + 1
    print("DCSF=", F)

    F, v1, v2 = mrmr.mrmr(XX,y,n_selected_features=16)
    F = np.array(F)
    F = F + 1
    print("mrmr=", F)

    # F = cfr(XX, y, k=16)
    # print("CFR=", F)

    F = MR_MNCI(XX, y, k=16)
    F = np.array(F)
    F = F + 1
    print("MR_MNCI=", F)

    F = MRMD(XX, y, n_selected_features=16)
    F = np.array(F)
    F = F + 1
    print("MRMD=", F)













