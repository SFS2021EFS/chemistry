
"""
分类模型【标签（0、4配位磷酸铝+>4配位磷酸铝+；1、杂原子稳定磷酸铝）】
1）77个分类结果评价数值；
2）4个分类结果；
3）8w+个样本分类比例；
p.s. exp = python3.9
"""

import csv
import warnings
import openpyxl
import graphviz
import time
import os
import numpy as np
import pandas as pd

from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from compute_W import compute_W
from Latent_features import Latent_features
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import export_graphviz
warnings.filterwarnings("ignore")
eps = 2.2204e-16

def save_as_csv(data):
    """将数组保存在.csv文件中"""
    with open('已知特征和选出的潜在特征.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        header = ["相对能量","P–Al–P angle variance","Al–P length (standard deviation)","P–P length (standard deviation)",
                  "CShM (AlP4)","AlP4 Volume","O–Al–O angle variance",
                  "Al–O length (standard deviation)","O–O length (standard deviation)", "CShM (AlO4)","AlO4 Volume",
                  "FD","Density","TD10","Num. Operators","Fraction","Latent_features_1","Latent_features_2","Latent_features_3"]
        writer.writerow(header)
        writer.writerows(data)

def discrete_5(X):
    """
    功能：数据集离散方法 分箱法(箱数=5)
    """
    sample_row,sample_colum=np.shape(X)
    for i in range(sample_colum):
        m=pd.cut(X[:,i],10,labels=[0,1,2,3,4,5,6,7,8,9])
        for j in range(sample_row):
            X[j,i]=m[j]
    return X

def IsBetterThanBefore(Result, CurrentResult):
    """
    :param Result:上次结束评估值
    :param CurrentResult:当前结束评估值
    :return:返回r指示器
    """
    a = CurrentResult
    b = Result
    if a > b:
        r = 1
    else:
        r = 0
    return r

def xlsx2matrix(path):
    """
    功能： 读取excel数据
    """
    data = openpyxl.load_workbook(path)
    table = data.worksheets[0]
    nrows  = table.max_row
    ncols = table.max_column
    datamatrix = np.zeros((nrows, ncols))
    i = 0
    for col in table.columns:
        col_val = [row.value for row in col]
        datamatrix[:,i]=col_val
        i+=1
    return datamatrix


if __name__ == "__main__":
    print("START:")

    # step1：读取数据
    dataset = xlsx2matrix(".\\dataset_81.xlsx")
    X = dataset[:, 0:15]
    Y = dataset[:, 15:16] - 1

    # step2：生成新增feature,且重要性排名第一
    gird = [0.00000001, 0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.01]

    Result = 0
    BestResult = 0
    alpha_best = 0.00000001
    for ii in range(len(gird)):
        alpha = gird[ii]
        X1, W, idx, temps = Latent_features(X, Y, alpha)
        #X1, W, idx, temps = Latent_features2(X, Y, alpha=alpha, beta=1, gamma=1)
        Y_pre = np.dot(X1, W)
        num, q = np.shape(Y_pre)
        Y_pre_discrete = np.zeros((num, q))
        for i in range(num):
            for j in range(q):
                if Y_pre[i, j] > 0.5:
                    Y_pre_discrete[i, j] = 1
                else:
                    Y_pre_discrete[i, j] = 0
        F1_Score = f1_score(Y, Y_pre_discrete, average='micro')
        Result = Result + F1_Score
        r = IsBetterThanBefore(BestResult, Result)
        if r == 1:
            BestResult = Result
            alpha_best = alpha

    lam1 = alpha_best
    X1, W, idx, total_features = Latent_features(X, Y, lam1)
    print("  total_features  =", total_features)
    print("        idx       =", idx)
    selected_idx = idx[0:1]
    print("   selected_idx   =", selected_idx)
    selected_features = X1[:, selected_idx]

    # step3：输出新旧特征&&标签到csv中：
    s_idx = np.arange(15).tolist()+selected_idx
    new_X1 = X1[:,s_idx]
    selected_features_all = np.hstack((new_X1, Y))
    pd.DataFrame(selected_features_all, columns=['ΔE','P–Al–P angle variance','Al–P length (standard deviation)','P–P length (standard deviation)',	'CShM (AlP4)','AlP4 Volume','O–Al–O angle variance','Al–O length (standard deviation)',	'O–O length (standard deviation)','CShM (AlO4)','AlO4 Volume', 'FD','TD10','Num. Operators','Fraction','new variable','label']).to_csv('.\\final_dataset_81.csv')

    # step4：训练分类器
    s_features = X1[:77, selected_idx]
    new_Y = Y[:77]
    classifier = DecisionTreeClassifier(criterion='entropy', max_depth=1, class_weight='balanced')
    classifier.fit(s_features, new_Y)

    # step5：画决策树图
    feature_name = [str(x) for x in selected_idx]
    class_name = ['0', '1']
    dot_data = export_graphviz(classifier, out_file='.\\honor_tree_v609.dot', feature_names=feature_name,
                               class_names=class_name, rounded=True, filled=True)
    graph = graphviz.Source(dot_data)
    os.environ["PATH"] += os.pathsep + r'F:\graphviz\bin'

    ori = '.\\honor_tree_v609.dot'
    image_path = '.\\honor_tree_v609.png'
    cmd_args = 'dot' + ' -Tpng ' + ori + ' -o ' + image_path
    os.system(cmd_args)

    # step6：77个分类结果评价数值
    Pre_Labels = classifier.predict(s_features)
    Column_Pre_Label = Pre_Labels.reshape(Pre_Labels.shape[0], 1)
    Recall_Score = recall_score(new_Y, Column_Pre_Label)
    Precision_Score = precision_score(new_Y, Column_Pre_Label)
    print("    Recall_Score  =", Recall_Score)
    print("  Precision_Score =", Precision_Score)

    # step7：相同分类模型，4个分类结果
    Pre_Labels_4 = classifier.predict(X1[77:81, selected_idx])
    print ("Four Pre_Labels =", Pre_Labels_4)
    Predict_Test_labels = Pre_Labels_4.reshape(Pre_Labels_4.shape[0], 1)

    # step8：相同分类模型，8w+个分类比例
    dataset84292 = xlsx2matrix(".\\dataset84292.xlsx")
    WWW = compute_W(X[:77,:], X1[:77, [idx[0]]])
    Predict_Test_Latent_features_84292 = np.dot(dataset84292, WWW)
    Pre_Labels_84292 = classifier.predict(Predict_Test_Latent_features_84292)

    zero_num = np.sum(Pre_Labels_84292 == 0)
    one_num = 84292 - zero_num
    print("zero_num =", zero_num)
    print("one_num  =", one_num)

    tempname = 'Column_Pre_Label_' + str(time.time()).split('.')[0] + '.csv'
    np.savetxt(tempname, Pre_Labels_84292, fmt='%d', delimiter=',')

    print("FINISH.")





