# coding=utf-8
import numpy as np
from numpy.random import seed
from numpy import linalg as LA
np.set_printoptions(threshold=np.inf)
np.set_printoptions(suppress=True)
import csv
eps = 2.2204e-16

def softmax(x):
    """Compute the softmax of vector x."""
    exps = np.exp(x)
    return exps / np.sum(exps)


def stablesoftmax(x):
    """Compute the softmax of vector x in a numerically stable way."""
    shiftx = x - np.max(x)
    exps = np.exp(shiftx)
    return exps / np.sum(exps)


def save_as_csv(data):
    """将数组保存在.csv文件中"""
    with open('对应特征的权重值.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        header = ["相对能量","P–Al–P angle variance","Al–P length (standard deviation)","P–P length (standard deviation)",
                  "CShM (AlP4)","AlP4 Volume","O–Al–O angle variance",
                  "Al–O length (standard deviation)","O–O length (standard deviation)", "CShM (AlO4)","AlO4 Volume",
                  "FD","Density","TD10","Num. Operators","Fraction"]
        writer.writerow(header)
        writer.writerows(data)


def compute_W(X, Y):
    num, d = X.shape
    num, l = Y.shape

    seed(1)
    W = np.random.random((d, l))

    iter = 0
    obj = []
    obji = 1

    while 1:
        # update W
        Q = np.true_divide(1, 2*abs(W)+eps)

        W = np.multiply(W, np.true_divide(np.dot(X.T, Y), np.dot(np.dot(X.T,X), W) + Q * W + eps))

        objectives = pow(LA.norm(np.dot(X, W) - Y, 'fro'), 2) + np.sum(abs(W))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if (iter > 2 and (cver < 1e-5 or iter == 10000)):
            break

    print("以下为各个已知特征对应的权重值:\n", W)

    return W