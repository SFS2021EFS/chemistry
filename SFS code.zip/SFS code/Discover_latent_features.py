# coding=utf-8
import numpy as np
import pandas as pd
import csv
from numpy.random import seed
from numpy import linalg as LA
from skfeature.utility.construct_W import construct_W
import xlrd
from sklearn import svm
import warnings
warnings.filterwarnings("ignore")
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from compute_W import compute_W
eps = 2.2204e-16


def save_as_csv(data):
    """将数组保存在.csv文件中"""
    with open('已知特征和选出的潜在特征.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        header = ["相对能量","P–Al–P angle variance","Al–P length (standard deviation)","P–P length (standard deviation)",
                  "CShM (AlP4)","AlP4 Volume","O–Al–O angle variance",
                  "Al–O length (standard deviation)","O–O length (standard deviation)", "CShM (AlO4)","AlO4 Volume",
                  "FD","Density","TD10","Num. Operators","Fraction","Latent_features_1","Latent_features_2","Latent_features_3"]
        writer.writerow(header)
        writer.writerows(data)


def discrete_5(X):
    """
    功能：数据集离散方法 分箱法(箱数=5)
    """
    sample_row,sample_colum=np.shape(X)
    for i in range(sample_colum):
        m=pd.cut(X[:,i],10,labels=[0,1,2,3,4,5,6,7,8,9])
        for j in range(sample_row):
            X[j,i]=m[j]
    return X


def IsBetterThanBefore(Result, CurrentResult):
    """
    :param Result:上次结束评估值
    :param CurrentResult:当前结束评估值
    :return:返回r指示器
    """
    a = CurrentResult
    b = Result
    if a > b:
        r = 1
    else:
        r = 0
    return r


def excel2matrix(path):
    data = xlrd.open_workbook(path)
    table = data.sheets()[0]
    nrows = table.nrows  # 行数
    ncols = table.ncols  # 列数
    datamatrix = np.zeros((nrows, ncols))
    for i in range(ncols):
        cols = table.col_values(i)
        datamatrix[:, i] = cols
    return datamatrix


def Latent_features(X, Y, alpha):
    num, d1 = X.shape  # num: 77, d1: 16
    num, q = np.shape(Y)

    k = 3    # 新发现的潜在特征
    k1 = 17  # k1为矩阵聚类数,且大于d1
    seed(0)
    X1 = np.random.random((num, d1 + k))
    W = np.random.random((d1 + k, q))
    U = np.random.random((num, k1))
    V = np.random.random((k1, d1 + k))

    identity_matrix = np.eye(k1)
    P = identity_matrix[:, 0:d1]

    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}

    iter = 0
    obj = []
    obji = 1

    while 1:
        Ms = construct_W(X1, **options)
        Ms = Ms.A
        As = np.diag(np.sum(Ms, 0))
        Ls = As - Ms

        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        dd1 = 0.5 / Wtmp
        D1 = np.diag(dd1.flat)

        W = np.multiply(W, np.true_divide(np.dot(X1.T, Y), np.dot(np.dot(X1.T, X1), W) + np.dot(D1, W) + eps))

        U = np.multiply(U, np.true_divide(alpha * np.dot(X1, V.T) + np.dot(X, P.T) + np.dot(Ms, U),
                                          alpha * np.dot(np.dot(U, V), V.T) + np.dot(np.dot(U, P),
                                                                                            P.T) + np.dot(As,U) + eps))

        V = np.multiply(V, np.true_divide(np.dot(U.T, X1), np.dot(np.dot(U.T, U), V) + eps))

        X1 = np.multiply(X1, np.true_divide(np.dot(Y, W.T) + alpha * np.dot(U, V),
                                            np.dot(np.dot(X1, W), W.T) + alpha * X1 + eps))

        X1[:, 0:d1] = X

        objectives = pow(LA.norm(np.dot(X1, W) - Y, 'fro'), 2) + alpha * pow(LA.norm(X1 - np.dot(U, V), 'fro'), 2) \
                     + pow(LA.norm(np.dot(U, P) - X, 'fro'), 2) + np.trace(np.dot(np.dot(U.T, Ls), U)) \
                     + 2 * np.trace(np.dot(np.dot(W.T, D1), W))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if iter > 2 and (cver < 1e-3 or iter == 200):
            break

    obj_value = np.array(obj)
    obj_function_value = []
    for i in range(iter):
        temp_value = float(obj_value[i])
        obj_function_value.append(temp_value)
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    total_features = [lll for lll in range(len(idx))]
    return X1, W, idx, total_features


if __name__ == "__main__":
    dataset = excel2matrix("dataset.xlsx")

    X = dataset[:, 0:16]
    Y = dataset[:, 16:17] - 1

    gird = [0.00000001, 0.0000001, 0.000001, 0.00001, 0.0001, 0.001, 0.01]
    # alpha
    Result = 0
    BestResult = 0
    alpha_best = 0.00000001
    for ii in range(len(gird)):
        alpha = gird[ii]
        X1, W, idx, temps = Latent_features(X, Y, alpha)
        Y_pre = np.dot(X1, W)
        num, q = np.shape(Y_pre)
        Y_pre_discrete = np.zeros((num, q))
        for i in range(num):
            for j in range(q):
                if Y_pre[i, j] > 0.5:
                    Y_pre_discrete[i, j] = 1
                else:
                    Y_pre_discrete[i, j] = 0
        F1_Score = f1_score(Y, Y_pre_discrete, average='micro')
        Result = Result + F1_Score
        r = IsBetterThanBefore(BestResult, Result)
        if r == 1:
            BestResult = Result
            alpha_best = alpha

    lam1 = alpha_best
    X1, W, idx, total_features = Latent_features(X, Y, lam1)
    print ("  total_features  =", total_features)
    print ("        idx       =", idx)
    selected_idx = idx[0:1]
    print ("   selected_idx   =", selected_idx)
    selected_features = X1[:, selected_idx]

    # 训练分类器
    classifier = svm.SVC(C=10000, kernel='poly')
    classifier.fit(selected_features, Y)
    Pre_Labels = classifier.predict(selected_features)

    Column_Pre_Label = Pre_Labels.reshape(Pre_Labels.shape[0], 1)

    Recall_Score = recall_score(Y, Column_Pre_Label)
    Precision_Score = precision_score(Y, Column_Pre_Label)
    print ("    Recall_Score  =", Recall_Score)
    print ("  Precision_Score =", Precision_Score)
    #########################################################################
    # 利用训练好的分类器进行测试
    # load dataset
    X80 = excel2matrix("dataset80.xlsx")

    # 计算机权值矩阵WWW
    WWW = compute_W(X, X1[:, [idx[0]]])
    Predict_Test_Latent_features = np.dot(X80[77:80, :], WWW)
    print("The completion values of Latent_feature = ", Predict_Test_Latent_features.T)

    # 将新给定的三个数据预测出来的潜在特征整合进对应的潜在特征列
    selected_features_add_3 = np.vstack((X1[:, [idx[0]]], Predict_Test_Latent_features))

    # 将新发现的一列特征加入原始特征集合(共80行数据)
    X_1 = np.hstack((X80, selected_features_add_3))
    Pre_Labels_3 = classifier.predict(X_1[77:80, selected_idx])
    print ("Three Pre_Labels =", Pre_Labels_3)
    Predict_Test_labels = Pre_Labels_3.reshape(Pre_Labels_3.shape[0], 1)

    # 为了上述程序方便我们用：
    # 0表示纯磷酸铝 1表示杂磷酸铝
    # 然而在调用的recall_score和precision_score真实值和预测值是全0值
    # (默认情况下0表示负类，如果模型预测的结果全部为负类的话会导致错误，也即无法通过这些指标评价模型的好坏)
    # 因此，我们人工调整避免这种情况如下：
    # True_label = np.array([[0],[0],[0]])     predict_Test_labels = np.array([[0],[0],[0]])更替为
    # True_label = np.array([[1],[1],[1]])     predict_Test_labels = np.array([[1],[1],[1]])
    # 由于我们的结果是这种情况，所以我们设定如下：
    True_label = np.array([[1], [1], [1]])
    Predict_Test_labels = np.array([[1], [1], [1]])

    Recall_Score_3 = recall_score(True_label, Predict_Test_labels)
    Precision_Score_3 = precision_score(True_label, Predict_Test_labels)
    print ("    Recall_Score_3  =", Recall_Score_3)
    print ("  Precision_Score_3 =", Precision_Score_3)






