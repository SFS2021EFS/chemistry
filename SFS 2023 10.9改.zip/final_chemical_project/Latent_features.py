# coding=utf-8
import numpy as np
import pandas as pd
import csv
from numpy.random import seed
from numpy import linalg as LA
from skfeature.utility.construct_W import construct_W
import xlrd
from sklearn import svm
import warnings
warnings.filterwarnings("ignore")
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from compute_W import compute_W
eps = 2.2204e-16


def Latent_features(X, Y, alpha):
    num, d1 = X.shape  # num: 77, d1: 15
    num, q = np.shape(Y)

    k = 2    # 新发现的潜在特征
    k1 = 16  # k1为矩阵聚类数,且大于d1
    seed(0)  # seed(0)
    X1 = np.random.random((num, d1 + k))
    W = np.random.random((d1 + k, q))
    U = np.random.random((num, k1))
    V = np.random.random((k1, d1 + k))

    identity_matrix = np.eye(k1)
    P = identity_matrix[:, 0:d1]

    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}

    iter = 0
    obj = []
    obji = 1

    while 1:
        Ms = construct_W(X1, **options)
        Ms = Ms.A
        As = np.diag(np.sum(Ms, 0))
        Ls = As - Ms

        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        dd1 = 0.5 / Wtmp
        D1 = np.diag(dd1.flat)

        W = np.multiply(W, np.true_divide(np.dot(X1.T, Y), np.dot(np.dot(X1.T, X1), W) + np.dot(D1, W) + eps))

        U = np.multiply(U, np.true_divide(alpha * np.dot(X1, V.T) + np.dot(X, P.T) + np.dot(Ms, U),
                                          alpha * np.dot(np.dot(U, V), V.T) + np.dot(np.dot(U, P),
                                                                                            P.T) + np.dot(As,U) + eps))

        V = np.multiply(V, np.true_divide(np.dot(U.T, X1), np.dot(np.dot(U.T, U), V) + eps))

        X1 = np.multiply(X1, np.true_divide(np.dot(Y, W.T) + alpha * np.dot(U, V),
                                            np.dot(np.dot(X1, W), W.T) + alpha * X1 + eps))

        X1[:, 0:d1] = X

        objectives = pow(LA.norm(np.dot(X1, W) - Y, 'fro'), 2) + alpha * pow(LA.norm(X1 - np.dot(U, V), 'fro'), 2) \
                     + pow(LA.norm(np.dot(U, P) - X, 'fro'), 2) + np.trace(np.dot(np.dot(U.T, Ls), U)) \
                     + 2 * np.trace(np.dot(np.dot(W.T, D1), W))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if iter > 2 and (cver < 1e-3 or iter == 1000):
            break

    obj_value = np.array(obj)
    obj_function_value = []
    for i in range(iter):
        temp_value = float(obj_value[i])
        obj_function_value.append(temp_value)
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    total_features = [lll for lll in range(len(idx))]
    return X1, W, idx, total_features

def Latent_features1(X, Y, alpha):
    num, d1 = X.shape  # num: 77, d1: 15
    num, q = np.shape(Y)

    k = 1    # 新发现的潜在特征
    k1 = 16  # k1为矩阵聚类数,且大于d1
    seed(0)  # seed(0)
    X1 = np.random.random((num, d1 + k))
    W = np.random.random((d1 + k, q))
    U = np.random.random((num, k1))
    V = np.random.random((k1, d1 + k))

    identity_matrix = np.eye(k1)
    P = identity_matrix[:, 0:d1]

    options = {'metric': 'euclidean', 'neighbor_mode': 'knn', 'k': 5, 'weight_mode': 'heat_kernel', 't': 1.0}

    iter = 0
    obj = []
    obji = 1

    while 1:
        Ms = construct_W(X1, **options)
        Ms = Ms.A
        As = np.diag(np.sum(Ms, 0))
        Ls = As - Ms

        Wtmp = np.sqrt(np.sum(np.multiply(W, W), 1) + eps)
        dd1 = 0.5 / Wtmp
        D1 = np.diag(dd1.flat)

        W = np.multiply(W, np.true_divide(np.dot(X1.T, Y), np.dot(np.dot(X1.T, X1), W) + np.dot(D1, W) + eps))

        U = np.multiply(U, np.true_divide(alpha * np.dot(X1, V.T) + np.dot(X, P.T) + np.dot(Ms, U),
                                          alpha * np.dot(np.dot(U, V), V.T) + np.dot(np.dot(U, P),
                                                                                            P.T) + np.dot(As,U) + eps))

        V = np.multiply(V, np.true_divide(np.dot(U.T, X1), np.dot(np.dot(U.T, U), V) + eps))

        X1 = np.multiply(X1, np.true_divide(np.dot(Y, W.T) + alpha * np.dot(U, V),
                                            np.dot(np.dot(X1, W), W.T) + alpha * X1 + eps))

        X1[:, 0:d1] = X

        objectives = pow(LA.norm(np.dot(X1, W) - Y, 'fro'), 2) + alpha * pow(LA.norm(X1 - np.dot(U, V), 'fro'), 2) \
                     + pow(LA.norm(np.dot(U, P) - X, 'fro'), 2) + np.trace(np.dot(np.dot(U.T, Ls), U)) \
                     + 2 * np.trace(np.dot(np.dot(W.T, D1), W))

        obj.append(objectives)
        cver = abs((objectives - obji) / float(obji))
        obji = objectives
        iter = iter + 1
        if iter > 2 and (cver < 1e-3 or iter == 200):
            break

    obj_value = np.array(obj)
    obj_function_value = []
    for i in range(iter):
        temp_value = float(obj_value[i])
        obj_function_value.append(temp_value)
    score = np.sum(np.multiply(W, W), 1)
    idx = np.argsort(-score, axis=0)
    idx = idx.T.tolist()
    total_features = [lll for lll in range(len(idx))]
    return X1, W, idx, total_features